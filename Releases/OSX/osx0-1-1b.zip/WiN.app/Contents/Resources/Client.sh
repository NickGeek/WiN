#!/bin/bash
python2.7 client.py