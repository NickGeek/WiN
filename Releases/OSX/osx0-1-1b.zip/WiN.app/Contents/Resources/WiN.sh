#!/bin/bash
nohup sh Client.sh&

python2.7 send.py